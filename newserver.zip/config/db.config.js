module.exports = {
  HOST: "localhost",
  USER: "bimtiano_admin",
  PASSWORD: "bimtiano_pass123",
  DB: "bimtiano_test",
  dialect: "mysql",

  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000,
  },
};
